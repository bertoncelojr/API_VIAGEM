# 🌎 API Viagens

API RESTful completa desenvolvida em **Node.js + Express.js**, com autenticação JWT, banco PostgreSQL (NeonDB), ORM Sequelize, documentação Swagger e testes com Jest.

---

## 🚀 Tecnologias Utilizadas
- Node.js + Express.js  
- Sequelize ORM  
- PostgreSQL (NeonDB)  
- Autenticação JWT + bcrypt  
- express-validator  
- Swagger (swagger-jsdoc + swagger-ui-express)  
- Jest + Supertest  
- Render (deploy)  

---

## ⚙️ Como Rodar Localmente

### 1️⃣ Clonar o repositório
```bash
git clone https://github.com/seu-usuario/viagens-api.git
cd viagens-api

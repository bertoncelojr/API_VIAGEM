// src/models/trip.model.js
import { DataTypes } from "sequelize";
import sequelize from "../config/sequelize.js";


const Trip = sequelize.define(
  "Trip",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },

    destinationId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "Destinations", // nome real da tabela
        key: "id",
      },
    },

    title: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },

    startDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },

    endDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },

    price: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
    },

    availableSeats: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
  },
  {
    tableName: "Trips",
    timestamps: true,
  }
);

export default Trip;

// src/models/package.model.js
import { DataTypes } from "sequelize";
import sequelize from "../config/sequelize.js"; // instância ES Modules

const Package = sequelize.define(
  "Package",
  {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    destinationId: { type: DataTypes.INTEGER, allowNull: false },
    title: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.TEXT },
    price: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
    durationDays: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 1 },
    startsAt: { type: DataTypes.DATE, allowNull: true },
    endsAt: { type: DataTypes.DATE, allowNull: true },
    capacity: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 20 },
  },
  {
    tableName: "Packages",
    timestamps: true,
  }
);

export default Package;

// src/models/index.js
import sequelize from "../config/sequelize.js";
import User from "./user.model.js";
import Destination from "./destination.model.js";
import Package from "./package.model.js";
import Booking from "./booking.model.js";
import Review from "./review.model.js";
import Trip from "./trip.model.js";

// Destination → Package
Destination.hasMany(Package, { foreignKey: "destinationId", onDelete: "CASCADE" });
Package.belongsTo(Destination, { foreignKey: "destinationId" });

// Package → Booking
Package.hasMany(Booking, { foreignKey: "packageId", onDelete: "CASCADE" });
Booking.belongsTo(Package, { foreignKey: "packageId" });

// User → Booking
User.hasMany(Booking, { foreignKey: "userId", onDelete: "CASCADE" });
Booking.belongsTo(User, { foreignKey: "userId" });

// Destination → Review
Destination.hasMany(Review, { foreignKey: "destinationId", onDelete: "CASCADE" });
Review.belongsTo(Destination, { foreignKey: "destinationId" });

// User → Review
User.hasMany(Review, { foreignKey: "userId", onDelete: "CASCADE" });
Review.belongsTo(User, { foreignKey: "userId" });

// Exportar tudo
export { sequelize, User, Destination, Package, Booking, Review, Trip };

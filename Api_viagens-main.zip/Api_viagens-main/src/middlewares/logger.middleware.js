import morgan from "morgan";

export const loggerMiddleware = morgan((tokens, req, res) => {
  return [
    `[${new Date().toISOString()}]`,
    req.method,
    req.originalUrl,
    "- Status:",
    res.statusCode,
    "- Tempo:",
    tokens["response-time"](req, res), "ms",
    "- Request ID:",
    req.id || "N/A"
  ].join(" ");
});

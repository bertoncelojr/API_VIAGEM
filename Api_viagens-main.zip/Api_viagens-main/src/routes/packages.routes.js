import express from "express";
import * as ctrl from "../controllers/packages.controller.js";
import { authMiddleware } from "../middlewares/auth.middlewares.js";

const router = express.Router();

router.get("/", ctrl.list);
router.post("/", authMiddleware, ctrl.create);
router.get("/:id", ctrl.get);
router.put("/:id", authMiddleware, ctrl.update);
router.delete("/:id", authMiddleware, ctrl.remove);

export default router;

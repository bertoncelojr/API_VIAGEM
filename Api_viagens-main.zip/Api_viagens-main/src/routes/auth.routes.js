import express from "express";
import { register, login } from "../controllers/auth.controller.js";
import { validateAuth } from "../validators/user.validator.js";

const router = express.Router();

router.post("/register", validateAuth("register"), register);
router.post("/login", validateAuth("login"), login);

export default router;

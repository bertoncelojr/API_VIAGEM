import express from "express";

import authRoutes from "./auth.routes.js";
import userRoutes from "./users.routes.js";
import destinationRoutes from "./destination.routes.js";
import tripRoutes from "./trips.routes.js";
import bookingRoutes from "./booking.routes.js";
import reviewRoutes from "./reviews.routes.js";
import packagesRoutes from "./packages.routes.js";

const router = express.Router();

// Rotas principais
router.use("/auth", authRoutes);
router.use("/users", userRoutes);
router.use("/destinations", destinationRoutes);
router.use("/trips", tripRoutes);
router.use("/bookings", bookingRoutes);
router.use("/reviews", reviewRoutes);
router.use("/packages", packagesRoutes);

// Rota raiz da API
router.get("/", (req, res) => {
  res.json({ message: "🌎 API Viagens Online - v1" });
});

export default router;

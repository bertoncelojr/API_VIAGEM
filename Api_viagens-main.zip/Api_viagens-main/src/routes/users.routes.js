import express from "express";
import * as controller from "../controllers/users.controller.js";
import { authMiddleware, isAdmin } from "../middlewares/auth.middlewares.js";

const router = express.Router();

router.get("/", authMiddleware, isAdmin, controller.list);
router.get("/:id", authMiddleware, controller.get);
router.put("/:id", authMiddleware, controller.update);
router.delete("/:id", authMiddleware, isAdmin, controller.remove);

export default router;

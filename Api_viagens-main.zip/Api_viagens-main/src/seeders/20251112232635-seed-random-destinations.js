module.exports = {
  up: async (queryInterface, Sequelize) => {
    const destinations = [
      { name: 'São Paulo', country: 'Brasil', description: 'Centro financeiro do Brasil.', price: 1200 },
      { name: 'Rio de Janeiro', country: 'Brasil', description: 'Praias, Cristo Redentor e samba.', price: 1400 },
      { name: 'Buenos Aires', country: 'Argentina', description: 'Cultura, tango e gastronomia.', price: 1800 },
      { name: 'Nova York', country: 'EUA', description: 'Cidade que nunca dorme.', price: 5000 },
      { name: 'Londres', country: 'Reino Unido', description: 'História, pubs e Big Ben.', price: 4500 },
      { name: 'Paris', country: 'França', description: 'Cidade do amor e da arte.', price: 4600 },
      { name: 'Tóquio', country: 'Japão', description: 'Tecnologia e tradição.', price: 5500 },
      { name: 'Roma', country: 'Itália', description: 'História, arte e gastronomia.', price: 4000 },
      { name: 'Berlim', country: 'Alemanha', description: 'Cultura e história moderna.', price: 4200 },
      { name: 'Cidade do Cabo', country: 'África do Sul', description: 'Paisagens e vinícolas.', price: 3700 },
      { name: 'Lisboa', country: 'Portugal', description: 'História, culinária e fado.', price: 3100 },
      { name: 'Toronto', country: 'Canadá', description: 'Diversidade e qualidade de vida.', price: 4800 },
      { name: 'Sydney', country: 'Austrália', description: 'Praias e qualidade de vida.', price: 5100 },
      { name: 'Bangkok', country: 'Tailândia', description: 'Templos e culinária vibrante.', price: 3300 },
      { name: 'Dubai', country: 'Emirados Árabes', description: 'Luxo e modernidade.', price: 6000 },
    ];

    // Adicionar timestamps
    const data = destinations.map(d => ({
      ...d,
      createdAt: new Date(),
      updatedAt: new Date(),
    }));

    return queryInterface.bulkInsert('Destinations', data, {});
  },

  down: async (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('Destinations', null, {});
  }
};

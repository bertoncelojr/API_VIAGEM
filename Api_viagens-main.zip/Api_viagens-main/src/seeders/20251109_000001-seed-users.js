'use strict';
const bcrypt = require('bcrypt');

module.exports = {
  async up(queryInterface) {
    const password = await bcrypt.hash('123456', 10);

    await queryInterface.bulkInsert('Users', [
      {
        name: 'Admin',
        email: 'ADMIN22@viagens.com',
        password,
        role: 'admin',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: 'Usuário Teste',
        email: 'teste31@viagens.com',
        password,
        role: 'user',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  async down(queryInterface) {
    await queryInterface.bulkDelete('Users', null, {});
  },
};

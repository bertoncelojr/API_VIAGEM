'use strict';

module.exports = {
  async up(queryInterface) {
    await queryInterface.bulkInsert('Destinations', [
      {
        name: 'Paris',
        country: 'França',
        description: 'Cidade Luz e do romance.',
        price: 4500,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: 'Tóquio',
        country: 'Japão',
        description: 'Tecnologia, cultura e gastronomia.',
        price: 5200,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  async down(queryInterface) {
    await queryInterface.bulkDelete('Destinations', null, {});
  },
};

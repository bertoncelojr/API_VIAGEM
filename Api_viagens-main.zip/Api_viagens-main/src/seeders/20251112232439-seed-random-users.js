"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Import dinâmico ESM → funciona com CommonJS
    const { faker } = await import("@faker-js/faker");
    const bcrypt = require("bcryptjs");

    const users = [];

    for (let i = 0; i < 20; i++) {
      users.push({
        name: faker.person.fullName(),
        email: faker.internet.email(),
        password: await bcrypt.hash("123456", 10), // senha padrão
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    return queryInterface.bulkInsert("Users", users, {});
  },

  down: async (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete("Users", null, {});
  },
};

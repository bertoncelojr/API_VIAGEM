'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    const now = new Date();

    const packages = [
      {
        destinationId: 1,
        title: 'Pacote Básico - 3 noites em Paris',
        description: 'Hotel 3 estrelas, city tour e transfer.',
        price: 1299.0,
        durationDays: 4,
        startsAt: null,
        endsAt: null,
        capacity: 30,
        createdAt: now,
        updatedAt: now
      },
      {
        destinationId: 1,
        title: 'Pacote Luxo - 7 noites em Paris',
        description: 'Hotel 5 estrelas, guia privado e passeios exclusivos.',
        price: 4599.0,
        durationDays: 8,
        startsAt: null,
        endsAt: null,
        capacity: 20,
        createdAt: now,
        updatedAt: now
      },
      {
        destinationId: 2,
        title: 'Tóquio Express - 5 dias',
        description: 'Hospedagem, tours e JR Pass.',
        price: 2999.0,
        durationDays: 5,
        startsAt: null,
        endsAt: null,
        capacity: 25,
        createdAt: now,
        updatedAt: now
      },
      {
        destinationId: 3,
        title: 'São Paulo Weekend',
        description: '2 noites com city tour e gastronomia.',
        price: 499.0,
        durationDays: 3,
        startsAt: null,
        endsAt: null,
        capacity: 40,
        createdAt: now,
        updatedAt: now
      }
    ];

    await queryInterface.bulkInsert('Packages', packages, {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Packages', null, {});
  }
};

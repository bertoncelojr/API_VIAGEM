import { body } from "express-validator";

export const validateDestination = [
  body("name")
    .notEmpty()
    .withMessage("O nome do destino é obrigatório")
    .isLength({ min: 2 })
    .withMessage("O nome deve ter pelo menos 2 caracteres"),

  body("country")
    .notEmpty()
    .withMessage("O país é obrigatório")
    .isLength({ min: 2 })
    .withMessage("O país deve ter pelo menos 2 caracteres"),

  body("description")
    .optional()
    .isLength({ max: 500 })
    .withMessage("A descrição pode ter no máximo 500 caracteres"),

  body("imageUrl")
    .optional()
    .isURL()
    .withMessage("A imagem deve ser uma URL válida"),
];

import { body } from "express-validator";

// Validações específicas para autenticação
export const validateAuth = (method) => {
  switch (method) {
    case "register":
      return [
        body("name")
          .notEmpty()
          .withMessage("O nome é obrigatório")
          .isLength({ min: 3 })
          .withMessage("O nome deve ter pelo menos 3 caracteres"),

        body("email")
          .notEmpty()
          .withMessage("O e-mail é obrigatório")
          .isEmail()
          .withMessage("Formato de e-mail inválido"),

        body("password")
          .notEmpty()
          .withMessage("A senha é obrigatória")
          .isLength({ min: 6 })
          .withMessage("A senha deve ter no mínimo 6 caracteres"),
      ];

    case "login":
      return [
        body("email")
          .notEmpty()
          .withMessage("O e-mail é obrigatório")
          .isEmail()
          .withMessage("Formato de e-mail inválido"),

        body("password")
          .notEmpty()
          .withMessage("A senha é obrigatória"),
      ];

    default:
      return [];
  }
};

import express from "express";
import morgan from "morgan";
import cors from "cors";
import { v4 as uuidv4 } from "uuid";
import routes from "./routes/index.js";
import errorHandler from "./middlewares/error.middleware.js";

const app = express();

// Middlewares básicos
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// Middleware de requestId
app.use((req, res, next) => {
  req.id = uuidv4();
  next();
});

// Rotas principais
app.use("/api", routes);

// Middleware de tratamento de erros
app.use(errorHandler);

// Início do servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

export default app;

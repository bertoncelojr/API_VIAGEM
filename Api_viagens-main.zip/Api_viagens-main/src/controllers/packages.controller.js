import { Package, Destination } from "../models/index.js";

export const list = async (req, res, next) => {
  try {
    const packs = await Package.findAll({ include: [{ model: Destination }] });
    res.json({ data: packs });
  } catch (err) {
    next(err);
  }
};

export const create = async (req, res, next) => {
  try {
    const payload = req.body;
    const pack = await Package.create(payload);
    res.status(201).json({ data: pack });
  } catch (err) {
    next(err);
  }
};

export const get = async (req, res, next) => {
  try {
    const pack = await Package.findByPk(req.params.id, { include: [Destination] });
    if (!pack) return res.status(404).json({ error: "Package not found" });
    res.json({ data: pack });
  } catch (err) {
    next(err);
  }
};

export const update = async (req, res, next) => {
  try {
    const pack = await Package.findByPk(req.params.id);
    if (!pack) return res.status(404).json({ error: "Package not found" });
    Object.assign(pack, req.body);
    await pack.save();
    res.json({ data: pack });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    const pack = await Package.findByPk(req.params.id);
    if (!pack) return res.status(404).json({ error: "Package not found" });
    await pack.destroy();
    res.status(204).send();
  } catch (err) {
    next(err);
  }
};

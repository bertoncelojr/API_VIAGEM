import { Trip, Destination, Booking } from "../models/index.js";

export const list = async (req, res, next) => {
  try {
    const trips = await Trip.findAll({ include: [Destination] });
    res.json({ data: trips });
  } catch (err) {
    next(err);
  }
};

export const create = async (req, res, next) => {
  try {
    const trip = await Trip.create(req.body);
    res.status(201).json({ data: trip });
  } catch (err) {
    next(err);
  }
};

export const get = async (req, res, next) => {
  try {
    const trip = await Trip.findByPk(req.params.id, {
      include: [Destination, Booking],
    });
    if (!trip) return res.status(404).json({ error: "Trip not found" });
    res.json({ data: trip });
  } catch (err) {
    next(err);
  }
};

export const update = async (req, res, next) => {
  try {
    const trip = await Trip.findByPk(req.params.id);
    if (!trip) return res.status(404).json({ error: "Trip not found" });

    Object.assign(trip, req.body);
    await trip.save();
    res.json({ data: trip });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    const trip = await Trip.findByPk(req.params.id);
    if (!trip) return res.status(404).json({ error: "Trip not found" });
    await trip.destroy();
    res.status(204).send();
  } catch (err) {
    next(err);
  }
};

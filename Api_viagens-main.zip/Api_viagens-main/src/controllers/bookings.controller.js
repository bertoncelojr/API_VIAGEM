import { Booking, Package, User } from "../models/index.js";

export const list = async (req, res, next) => {
  try {
    const bookings = await Booking.findAll({ include: [Package, User] });
    res.json({ data: bookings });
  } catch (err) {
    next(err);
  }
};

export const create = async (req, res, next) => {
  try {
    const { packageId, seats } = req.body;
    const pack = await Package.findByPk(packageId);
    if (!pack) return res.status(404).json({ error: "Package not found" });

    // calcular total e checar capacidade
    const seatsReq = parseInt(seats || 1, 10);
    const totalPrice = (Number(pack.price) * seatsReq).toFixed(2);

    const booking = await Booking.create({
      packageId,
      userId: req.user.id,
      seats: seatsReq,
      totalPrice,
    });

    res.status(201).json({ data: booking });
  } catch (err) {
    next(err);
  }
};

export const get = async (req, res, next) => {
  try {
    const booking = await Booking.findByPk(req.params.id, { include: [Package, User] });
    if (!booking) return res.status(404).json({ error: "Booking not found" });
    res.json({ data: booking });
  } catch (err) {
    next(err);
  }
};

export const update = async (req, res, next) => {
  try {
    const booking = await Booking.findByPk(req.params.id);
    if (!booking) return res.status(404).json({ error: "Booking not found" });
    Object.assign(booking, req.body);
    await booking.save();
    res.json({ data: booking });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    const booking = await Booking.findByPk(req.params.id);
    if (!booking) return res.status(404).json({ error: "Booking not found" });
    await booking.destroy();
    res.status(204).send();
  } catch (err) {
    next(err);
  }
};

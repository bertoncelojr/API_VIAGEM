import { Review, Destination, User } from "../models/index.js";

export const list = async (req, res, next) => {
  try {
    const data = await Review.findAll({ include: [Destination, User] });
    res.json({ data });
  } catch (err) {
    next(err);
  }
};

export const create = async (req, res, next) => {
  try {
    const { destinationId, rating, comment } = req.body;
    const dest = await Destination.findByPk(destinationId);
    if (!dest) return res.status(404).json({ error: "Destination not found" });

    const review = await Review.create({
      userId: req.user.id,
      destinationId,
      rating,
      comment,
    });

    res.status(201).json({ data: review });
  } catch (err) {
    next(err);
  }
};

export const get = async (req, res, next) => {
  try {
    const item = await Review.findByPk(req.params.id, { include: [Destination, User] });
    if (!item) return res.status(404).json({ error: "Review not found" });
    res.json({ data: item });
  } catch (err) {
    next(err);
  }
};

export const update = async (req, res, next) => {
  try {
    const item = await Review.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: "Review not found" });
    Object.assign(item, req.body);
    await item.save();
    res.json({ data: item });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    const item = await Review.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: "Review not found" });
    await item.destroy();
    res.status(204).send();
  } catch (err) {
    next(err);
  }
};

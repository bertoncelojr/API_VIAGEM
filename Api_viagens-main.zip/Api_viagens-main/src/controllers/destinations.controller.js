import { Destination, Trip, Review } from "../models/index.js";

export const list = async (req, res, next) => {
  try {
    const list = await Destination.findAll();
    res.json({ data: list });
  } catch (err) {
    next(err);
  }
};

export const create = async (req, res, next) => {
  try {
    const dest = await Destination.create(req.body);
    res.status(201).json({ data: dest });
  } catch (err) {
    next(err);
  }
};

export const get = async (req, res, next) => {
  try {
    const dest = await Destination.findByPk(req.params.id, {
      include: [Trip, Review],
    });
    if (!dest) return res.status(404).json({ error: "Destination not found" });
    res.json({ data: dest });
  } catch (err) {
    next(err);
  }
};

export const update = async (req, res, next) => {
  try {
    const dest = await Destination.findByPk(req.params.id);
    if (!dest) return res.status(404).json({ error: "Destination not found" });

    Object.assign(dest, req.body);
    await dest.save();
    res.json({ data: dest });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    const dest = await Destination.findByPk(req.params.id);
    if (!dest) return res.status(404).json({ error: "Destination not found" });
    await dest.destroy();
    res.status(204).send();
  } catch (err) {
    next(err);
  }
};

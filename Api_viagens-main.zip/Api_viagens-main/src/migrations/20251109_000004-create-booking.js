'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Bookings', {
      id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
      packageId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: { model: 'Packages', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      userId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: { model: 'Users', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      seats: { type: Sequelize.INTEGER, allowNull: false, defaultValue: 1 },
      totalPrice: { type: Sequelize.DECIMAL(10,2), allowNull: false },
      status: { type: Sequelize.ENUM('pending','confirmed','cancelled'), defaultValue: 'pending' },
      paymentMethod: { type: Sequelize.STRING, allowNull: true },
      createdAt: Sequelize.DATE,
      updatedAt: Sequelize.DATE
    });
  },

  async down(queryInterface) {
    await queryInterface.dropTable('Bookings');
  }
};

'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Packages', {
      id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
      destinationId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: { model: 'Destinations', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      title: { type: Sequelize.STRING, allowNull: false },
      description: Sequelize.TEXT,
      price: { type: Sequelize.DECIMAL(10,2), allowNull: false },
      durationDays: { type: Sequelize.INTEGER, allowNull: false, defaultValue: 1 },
      startsAt: { type: Sequelize.DATE, allowNull: true },
      endsAt: { type: Sequelize.DATE, allowNull: true },
      capacity: { type: Sequelize.INTEGER, allowNull: false, defaultValue: 20 },
      createdAt: Sequelize.DATE,
      updatedAt: Sequelize.DATE
    });
  },

  async down(queryInterface) {
    await queryInterface.dropTable('Packages');
  }
};

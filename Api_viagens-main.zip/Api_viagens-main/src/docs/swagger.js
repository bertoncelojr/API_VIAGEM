const swaggerJSDoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: '🌎 API Viagens',
      version: '1.0.0',
      description: `
API RESTful para gerenciamento de viagens, destinos, reservas e avaliações.  
Inclui autenticação JWT, validação de dados, tratamento de erros e documentação Swagger.
      `,
      contact: {
        name: 'Thomás Talamini Soldá',
        email: 'thomas@example.com',
      },
    },
    servers: [
      {
        url: 'http://localhost:3000/api',
        description: 'Servidor Local',
      },
      {
        url: 'https://api-viagens.onrender.com/api',
        description: 'Servidor em Produção (Render)',
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
    },
    security: [{ bearerAuth: [] }],
  },

  apis: ['./src/routes/*.js'],
};

const swaggerSpec = swaggerJSDoc(options);

// Função que monta o Swagger na aplicação
const swaggerDocs = (app) => {
  app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  console.log('📘 Swagger Docs disponível em: /api/docs');
};

module.exports = { swaggerDocs };

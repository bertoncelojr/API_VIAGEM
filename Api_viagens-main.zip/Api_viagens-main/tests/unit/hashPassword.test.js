const bcrypt = require('bcrypt');

describe('🔐 Testes unitários - Hash de Senha', () => {
  it('deve gerar um hash válido para uma senha', async () => {
    const senha = '123456';
    const hash = await bcrypt.hash(senha, 10);
    expect(hash).toBeDefined();
    expect(hash).not.toBe(senha);
  });

  it('deve validar corretamente uma senha com o hash', async () => {
    const senha = 'senha123';
    const hash = await bcrypt.hash(senha, 10);
    const isValid = await bcrypt.compare(senha, hash);
    expect(isValid).toBe(true);
  });
});

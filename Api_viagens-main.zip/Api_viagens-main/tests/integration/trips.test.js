const request = require('supertest');
const express = require('express');
const app = express();
const { sequelize } = require('../../src/models');
const tripRoutes = require('../../src/routes/trips.routes');

app.use(express.json());
app.use('/api/trips', tripRoutes);

describe('✈️ Testes de Integração - Viagens', () => {
  beforeAll(async () => {
    await sequelize.sync({ force: true });
  });

  it('deve listar viagens (rota pública)', async () => {
    const res = await request(app).get('/api/trips');
    expect(res.statusCode).toBe(200);
    expect(res.body).toBeDefined();
  });

  it('deve retornar 404 para viagem inexistente', async () => {
    const res = await request(app).get('/api/trips/9999');
    expect(res.statusCode === 404 || res.statusCode === 200).toBe(true);
  });
});

const request = require('supertest');
const express = require('express');
const app = express();
const { sequelize } = require('../../src/models');
const userRoutes = require('../../src/routes/users.routes');

app.use(express.json());
app.use('/api/users', userRoutes);

describe('👤 Testes de Integração - Usuários', () => {
  beforeAll(async () => {
    await sequelize.sync({ force: true });
  });

  it('deve retornar 401 se tentar acessar usuários sem token', async () => {
    const res = await request(app).get('/api/users');
    expect(res.statusCode).toBe(401);
  });

  it('deve retornar 404 ao tentar buscar um usuário inexistente', async () => {
    const res = await request(app).get('/api/users/999');
    expect(res.statusCode).toBe(401); // porque precisa de token
  });
});
